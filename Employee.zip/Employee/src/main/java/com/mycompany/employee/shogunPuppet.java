/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Lenovo
 */
public class shogunPuppet extends Harbinger6th {     
    public float Komisi_3080;     
    public float TotalHslProyek_3080;     
    public double Totalgaji_3080; 
     
    public shogunPuppet(){ 
         
    }              
    public double TotalGaji_3080(){ 
        Totalgaji_3080 = (gajiPokok_3080 *5/100) - gajiPokok_3080 + (Komisi_3080 * TotalHslProyek_3080);         
        return Totalgaji_3080; 
    } 
        public void TampilData_3080(){ 
        System.out.println("Perancang Proyek"); 
        Tampil_3080(); 
        System.out.println("Total Gaji: " + Totalgaji_3080); 
    } 
} 

