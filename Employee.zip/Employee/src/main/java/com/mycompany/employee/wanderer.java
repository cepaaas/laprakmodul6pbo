/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.employee;

/**
 *
 * @author Lenovo
 */
public class wanderer extends Harbinger6th {      
    public float Komisi_3080;     
    public float TotalPenjualan_3080;     
    public float Totalgaji_3080; 
    String nama_3080;
     
     public wanderer(){ 
         
    } 
     
    public float TotalGaji_3080(){ 
        Totalgaji_3080 = gajiPokok_3080 + (Komisi_3080 * TotalPenjualan_3080);         
        return Totalgaji_3080; 
    } 

    public void TampilData_3080(){ 
        System.out.println("Komisi Karyawan"); 
        Tampil_3080(); 
        System.out.println("Total Gaji: " + Totalgaji_3080); 
    } 
} 
