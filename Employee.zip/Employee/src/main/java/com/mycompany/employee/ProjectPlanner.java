/* 
*	Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license 
*	Click 
nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${pack agePath}/${mainClassName}.java to edit this template 
 */ 
 
package com.mycompany.employee; 
 
import java.io.BufferedReader; import java.io.InputStreamReader; 
 
/** 
 * 
*	@author Judecca_GilangFibarkah_21103080  
 */ 
public class ProjectPlanner { 
 
    public static void main(String[] args) {        
        scaramouche cepa_3080 = new scaramouche();         
        wanderer algivari_3080 = new wanderer();         
        shogunPuppet sulaiman_3080 = new shogunPuppet(); 
         
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));  
      
        try{ 
            System.out.println("Data Pegawai");             
            System.out.print("Nama              : ");             
            cepa_3080.nama_3080 = br.readLine(); 
            System.out.print("NIP               : ");             
            cepa_3080.nip_3080 = br.readLine();             
            System.out.print("Gaji Pokok        : "); 
            cepa_3080.gajiPokok_3080 = Float.valueOf(br.readLine());             
            System.out.println("");             
            cepa_3080.TampilData_3080(); 
            System.out.println(""); 
            System.out.println(""); 
             
            System.out.print("Nama              : ");             
            algivari_3080.nama_3080 = br.readLine();             
            System.out.print("NIP               : ");             
            algivari_3080.nip_3080 = br.readLine();             
            System.out.print("GajiPokok         : "); 
            algivari_3080.gajiPokok_3080 = Float.parseFloat(br.readLine());             
            System.out.print("Komisi            : "); 
            algivari_3080.Komisi_3080 = Float.parseFloat(br.readLine());             
            System.out.print("Total Penjualan   : "); 
            algivari_3080.TotalPenjualan_3080 = Float.parseFloat(br.readLine());             
            algivari_3080.TotalGaji_3080();             
            System.out.println("");             
            algivari_3080.TampilData_3080(); 
            System.out.println("");             
            System.out.println(""); 
             
            System.out.print("Nama              : ");             
            sulaiman_3080.nama_3080 = br.readLine();             
            System.out.print("NIP               : ");             
            sulaiman_3080.nip_3080 = br.readLine(); 
            System.out.print("Gaji Pokok        : "); 
            sulaiman_3080.gajiPokok_3080 = Float.parseFloat(br.readLine());             
            System.out.print("Komisi            : "); 
            sulaiman_3080.Komisi_3080 = Float.parseFloat(br.readLine());             
            System.out.print("Total Hasil Proyek: "); 
            sulaiman_3080.TotalHslProyek_3080 = Float.parseFloat(br.readLine());             
            sulaiman_3080.TotalGaji_3080();             
            System.out.println("");             
            sulaiman_3080.TampilData_3080();            
        } 
         
        catch(Exception ex){ 
            System.out.println(ex); 
        } 
    } 
} 
